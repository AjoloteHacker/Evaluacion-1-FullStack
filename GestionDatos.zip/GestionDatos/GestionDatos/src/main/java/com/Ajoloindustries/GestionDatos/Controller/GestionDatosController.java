package com.Ajoloindustries.GestionDatos.Controller;

import com.Ajoloindustries.GestionDatos.Model.Estado;
import com.Ajoloindustries.GestionDatos.Model.GestionDatosModel;
import com.Ajoloindustries.GestionDatos.Service.GestionDatosService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
public class GestionDatosController {


}
