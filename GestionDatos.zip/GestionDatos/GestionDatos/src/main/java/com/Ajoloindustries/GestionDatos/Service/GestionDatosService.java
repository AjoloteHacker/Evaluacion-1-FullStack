package com.Ajoloindustries.GestionDatos.Service;

import com.Ajoloindustries.GestionDatos.Model.Estado;
import com.Ajoloindustries.GestionDatos.Model.GestionDatosModel;
import com.Ajoloindustries.GestionDatos.Repository.GestionDatosRepository;
import jakarta.validation.constraints.NotNull;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class GestionDatosService {

    private final GestionDatosRepository repo;

    public GestionDatosService(GestionDatosRepository repo) {this.repo = repo;}

    public List<GestionDatosModel> listar() {return repo.obtenerTodos(); }

    public GestionDatosModel

}
