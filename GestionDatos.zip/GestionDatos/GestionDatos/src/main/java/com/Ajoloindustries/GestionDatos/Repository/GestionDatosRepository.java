package com.Ajoloindustries.GestionDatos.Repository;

public class GestionDatosRepository {
}
