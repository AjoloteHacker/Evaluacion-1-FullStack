package com.Ajoloindustries.GestionDatos.Model;

import java.time.LocalDate;

public class GestionDatosModel {
    private Long id;
    private String nombreCliente;
    private Estado Estado;
    private String descripcion;
    private tipoPedido tipoPedido;
    private Double montoTotal;
    private LocalDate fechaPedido;

    public GestionDatosModel(Long id, String nombreCliente, Estado estado, String descripcion, tipoPedido tipoPedido, Double montoTotal, LocalDate fechaPedido) {
        this.id = id;
        this.nombreCliente = nombreCliente;
        Estado = estado;
        this.descripcion = descripcion;
        this.tipoPedido = tipoPedido;
        this.montoTotal = montoTotal;
        this.fechaPedido = fechaPedido;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreCliente() {return nombreCliente;}

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public Estado getEstado() {
        return Estado;
    }

    public void setEstado(Estado estado) {Estado = estado;}

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public tipoPedido getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(tipoPedido tipoPedido) {
        this.tipoPedido = tipoPedido;
    }

    public Double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(Double montoTotal) {
        this.montoTotal = montoTotal;
    }

    public LocalDate getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(LocalDate fechaPedido) {
        this.fechaPedido = fechaPedido;
    }
}
