package com.Ajoloindustries.GestionDatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDatosApplication.class, args);
	}

}
