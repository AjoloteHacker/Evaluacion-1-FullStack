package com.Ajoloindustries.GestionDatos.Model;

public enum tipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS

}
