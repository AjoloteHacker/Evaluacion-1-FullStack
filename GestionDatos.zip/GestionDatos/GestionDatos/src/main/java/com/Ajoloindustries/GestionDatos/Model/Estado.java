package com.Ajoloindustries.GestionDatos.Model;

public enum Estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}
