package com.Ajoloindustries.GestionDatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
