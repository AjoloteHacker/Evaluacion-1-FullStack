package com.Ajoloindustries.GestionDatos.Model;
//Enum
public enum estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}
