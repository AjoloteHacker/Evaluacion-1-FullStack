package com.Ajoloindustries.GestionDatos.Repository;

import com.Ajoloindustries.GestionDatos.Model.estado;
import com.Ajoloindustries.GestionDatos.Model.GestionDatosModel;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class GestionDatosRepository {
    private List<GestionDatosModel> lista = new ArrayList<>();
    private Long contador = 1L;

    public List<GestionDatosModel> obtenerTodos() {
        return lista;
    }
    public GestionDatosModel guardar(GestionDatosModel p) {
        p.setId(contador++);
        lista.add(p);
        return p;
    }

    public Optional<GestionDatosModel> buscarPorId(long id) {
        return lista.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();

    }
    public void eliminar(Long id) {
        lista.removeIf(p -> p.getId().equals(id));
    }

    public GestionDatosModel actualizar(Long id, GestionDatosModel datosNuevos) {
        Optional<GestionDatosModel> pedidoExistente = buscarPorId(id);
        if (pedidoExistente.isPresent()) {
            GestionDatosModel p = pedidoExistente.get();
            p.setNombreCliente(datosNuevos.getNombreCliente());
            p.setDescripcion(datosNuevos.getDescripcion());
            p.setEstado(datosNuevos.getEstado());
            p.setTipoPedido(datosNuevos.getTipoPedido());
            p.setMontoTotal(datosNuevos.getMontoTotal());
            return p;
        }
        return null;
    }

    public List<GestionDatosModel> buscarPorEstado(estado estado) {
        return lista.stream()
                .filter(p -> p.getEstado() == estado)
                .toList();
    }
}
