package com.Ajoloindustries.GestionDatos.Model;

import java.time.LocalDate;
//Variuables utilizadas
public class GestionDatosModel { //Clases usadas
    private Long id;
    private String nombreCliente;
    private estado estado;
    private String descripcion;
    private tipoPedido tipoPedido;
    private Double montoTotal;
    private LocalDate fechaPedido;

    public GestionDatosModel() {}
//Constructores
    public GestionDatosModel(Long id, String nombreCliente, estado estado, String descripcion, tipoPedido tipoPedido, Double montoTotal, LocalDate fechaPedido) {
        this.id = id;
        this.nombreCliente = nombreCliente;
        this.estado = estado;
        this.descripcion = descripcion;
        this.tipoPedido = tipoPedido;
        this.montoTotal = montoTotal;
        this.fechaPedido = fechaPedido;
    }
//Getter and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreCliente() {return nombreCliente;}

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public estado getEstado() {
        return estado;
    }

    public void setEstado(estado estado) {
        this.estado = estado;}

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public tipoPedido getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(tipoPedido tipoPedido) {
        this.tipoPedido = tipoPedido;
    }

    public Double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(Double montoTotal) {
        this.montoTotal = montoTotal;
    }

    public LocalDate getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(LocalDate fechaPedido) {
        this.fechaPedido = fechaPedido;
    }
}
