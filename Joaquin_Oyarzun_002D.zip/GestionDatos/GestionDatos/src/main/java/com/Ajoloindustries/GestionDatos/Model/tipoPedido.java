package com.Ajoloindustries.GestionDatos.Model;
//Enum
public enum tipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS

}
