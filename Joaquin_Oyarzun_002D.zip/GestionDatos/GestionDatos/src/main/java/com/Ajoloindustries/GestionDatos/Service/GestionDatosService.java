package com.Ajoloindustries.GestionDatos.Service;

import com.Ajoloindustries.GestionDatos.Model.GestionDatosModel;
import com.Ajoloindustries.GestionDatos.Model.estado;
import com.Ajoloindustries.GestionDatos.Repository.GestionDatosRepository;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class GestionDatosService {

    private final GestionDatosRepository repo;

    public GestionDatosService(GestionDatosRepository repo) {this.repo = repo;}

    public List<GestionDatosModel> listar() {return repo.obtenerTodos(); }

    public GestionDatosModel obtenerPorId(Long id) {
        return repo.buscarPorId(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

    }
    public GestionDatosModel crear(@NotNull GestionDatosModel p) {
        if (p.getNombreCliente() == null || p.getNombreCliente().isEmpty()) {
            throw new RuntimeException("Nombre obligatorio");
        }

        if (p.getMontoTotal() == null || p.getMontoTotal() <= 0) {
            throw new RuntimeException("Monto debe ser mayor a 0");
        }

        p.setFechaPedido(LocalDate.now());
        return repo.guardar(p);
    }

    public GestionDatosModel actualizar(Long id, GestionDatosModel nuevo) {
        GestionDatosModel existente = obtenerPorId(id);

        existente.setNombreCliente(nuevo.getNombreCliente());
        existente.setDescripcion(nuevo.getDescripcion());
        existente.setEstado(nuevo.getEstado());
        existente.setTipoPedido(nuevo.getTipoPedido());
        existente.setMontoTotal(nuevo.getMontoTotal());

        return existente;
    }

    public void eliminar(Long id) {
        obtenerPorId(id);
        repo.eliminar(id);
    }

    public List<GestionDatosModel> filtrarPorEstado(estado estado) {
        return repo.obtenerTodos().stream()
                .filter(p -> p.getEstado() == estado)
                .toList();
    }
}

