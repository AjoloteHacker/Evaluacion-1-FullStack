package com.Ajoloindustries.GestionDatos.Controller;

import com.Ajoloindustries.GestionDatos.Model.estado;
import com.Ajoloindustries.GestionDatos.Model.GestionDatosModel;
import com.Ajoloindustries.GestionDatos.Service.GestionDatosService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pedidos") //base de datos
public class GestionDatosController {

    private final GestionDatosService GestionDatosService;

    public GestionDatosController(GestionDatosService GestionDatosService) {
        this.GestionDatosService = GestionDatosService;
    }

    @GetMapping //Buscar Datos
    public ResponseEntity<List<GestionDatosModel>> obtenerTodos() {
        return ResponseEntity.ok(GestionDatosService.listar());
    }

    @GetMapping("/{id}") //busca por ID
    public ResponseEntity<GestionDatosModel> obtenerporId(@PathVariable Long id) {
        return ResponseEntity.ok(GestionDatosService.obtenerPorId(id));
    }

    @PostMapping //Agregar Datos
    public ResponseEntity<GestionDatosModel> crearPedido(@RequestBody GestionDatosModel pedido) {
        GestionDatosModel nuevoPedido = GestionDatosService.crear(pedido);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoPedido);
    }

    @PutMapping("/{id}") //Edita Datos
    public ResponseEntity<GestionDatosModel> actualizarPedido(@PathVariable Long id, @RequestBody GestionDatosModel pedido) {
        GestionDatosModel pedidoActualizado = GestionDatosService.actualizar(id, pedido);
        return ResponseEntity.ok(pedidoActualizado);
    }

    @DeleteMapping("/{id}") //Borra Datos Por ID
    public ResponseEntity<Void> eliminarPedido(@PathVariable Long id) {
        GestionDatosService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/estado/{estado}") //Busca por Estado del pedido
    public ResponseEntity<List<GestionDatosModel>> obtenerPorEstado(@PathVariable estado estado) {
        return ResponseEntity.ok(GestionDatosService.filtrarPorEstado(estado));

    }
}
